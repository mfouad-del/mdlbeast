/* share-modal.js stub - placeholder to prevent 404 errors */
(function() {
  // This is a stub file to prevent 404 errors when external scripts try to load this file
  // It can be safely ignored or removed if not needed
  if (typeof window !== 'undefined' && window.console) {
    // Silently ignore - this is expected behavior
  }
})();
